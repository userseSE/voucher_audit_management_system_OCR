create definer = root@localhost trigger insert_check_vou_info
    after insert
    on vouchers
    for each row
BEGIN
  INSERT INTO check_vou_info (comp,vou_id,vou_date,vou_acc,con_acc,amount,need_vouch)
  VALUES (NEW.comp, NEW.vou_id, NEW.vou_date,NEW.vou_acc,NEW.con_acc,NEW.amount,NEW.need_vouch);
END;

