create definer = root@localhost trigger update_check_vou_info
    before update
    on vouchers
    for each row
BEGIN
  UPDATE check_vou_info
  SET     vou_acc = NEW.vou_acc,
      con_acc = NEW.con_acc,
      amount = NEW.amount,
      need_vouch=NEW.need_vouch
  WHERE check_vou_info.comp = OLD.comp AND check_vou_info.vou_id = OLD.vou_id AND check_vou_info.vou_date=OLD.vou_date;
END;

