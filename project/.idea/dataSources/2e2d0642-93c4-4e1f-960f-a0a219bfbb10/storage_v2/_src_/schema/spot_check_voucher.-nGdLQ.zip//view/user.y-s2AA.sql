create definer = root@localhost view user as
select `spot_check_voucher`.`intern`.`position`    AS `active_name2`,
       `spot_check_voucher`.`intern`.`intern_id`   AS `intern_id`,
       `spot_check_voucher`.`intern`.`intern_name` AS `intern_name`,
       `spot_check_voucher`.`intern`.`i_key`       AS `i_key`
from `spot_check_voucher`.`intern`
union all
select `spot_check_voucher`.`auditor`.`position`   AS `active_name2`,
       `spot_check_voucher`.`auditor`.`auditor_id` AS `auditor_id`,
       `spot_check_voucher`.`auditor`.`auditor`    AS `auditor`,
       `spot_check_voucher`.`auditor`.`a_key`      AS `a_key`
from `spot_check_voucher`.`auditor`
union all
select `spot_check_voucher`.`manager`.`position`   AS `active_name2`,
       `spot_check_voucher`.`manager`.`admin_id`   AS `admin_id`,
       `spot_check_voucher`.`manager`.`admin_name` AS `admin_name`,
       `spot_check_voucher`.`manager`.`ad_key`     AS `ad_key`
from `spot_check_voucher`.`manager`;

